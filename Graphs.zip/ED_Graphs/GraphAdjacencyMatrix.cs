﻿namespace Graphs
{
    // Representação de grafo(com peso) utilizando matriz de adjacência. 
    internal class GraphAdjacencyMatrix<T>
    {
        private T[] _vertices = [];
        private int[,] _edges = new int[0, 0];

        public T[] Vertices => _vertices;

        public void AddVertex(T value)
        {
            T[] newVertices = new T[_vertices.Length + 1];
            for (int i = 0; i < _vertices.Length; i++)
            {
                newVertices[i] = _vertices[i];
            }
            newVertices[_vertices.Length] = value;
            _vertices = newVertices;

            int[,] newEdges = new int[_vertices.Length, _vertices.Length];
            for (int i = 0; i < _edges.GetLength(0); i++)
            {
                for (int j = 0; j < _edges.GetLength(1); j++)
                {
                    newEdges[i, j] = _edges[i, j];
                }
            }
            _edges = newEdges;
        }

        public void RemoveVertex(int index)
        {
            if (index < 0 || index >= _vertices.Length)
            {
                throw new ArgumentOutOfRangeException("Vértice inexistente!");
            }

            int newLength = _vertices.Length - 1;

            T[] newVertices = new T[newLength];
            for (int i = 0; i < newLength; i++)
            {
                newVertices[i] = _vertices[i + (i >= index ? 1 : 0)];
            }
            _vertices = newVertices;

            int[,] newEdges = new int[newLength, newLength];
            for (int i = 0; i < _edges.GetLength(0); i++)
            {
                for (int j = 0; j < _edges.GetLength(1); j++)
                {
                    newEdges[i, j] = _edges[i + (i >= index ? 1 : 0), j + (j >= index ? 1 : 0)];
                }
            }
            _edges = newEdges;
        }

        public T GetVertex(int index)
        {
            return _vertices[index];
        }

        public void SetVertex(int index, T value)
        {
            _vertices[index] = value;
        }

        public void AddEdge(int from, int to)
        {
            SetEdge(from, to, 1);
        }

        public void RemoveEdge(int from, int to)
        {
            _edges[from, to] = 0;
        }

        public int GetEdge(int from, int to)
        {
            return _edges[from, to];
        }

        public void SetEdge(int from, int to, int weight)
        {
            _edges[from, to] = weight;
        }

        public bool HasEdge(int from, int to)
        {
            return _edges[from, to] > 0;
        }

        public List<(int index, int weight)> GetNeighbours(int index)
        {
            List<(int, int)> neighbours = new();

            for (int i = 0; i < _vertices.Length; i++)
            {
                if (HasEdge(index, i))
                {
                    neighbours.Add((i, GetEdge(index, i)));
                }
            }
            return neighbours;
        }
    }
}
