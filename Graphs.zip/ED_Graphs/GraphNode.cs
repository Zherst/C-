﻿namespace Graphs
{
    delegate void GraphProcess<T>(ref T value);
    delegate void GraphProcessConst<T>(T value);

    internal class GraphNode<T>
    {
        public T value;
        
        private List<GraphNode<T>> _neighbours = new();
        public int NeighbourCount => _neighbours.Count;


        public GraphNode(T value)
        {
            this.value = value;
        }

        public GraphNode<T> GetNeighbour(int index)
        {
            return _neighbours[index];
        }

        // Conexão em sentido único
        public void ConnectOneWay(GraphNode<T> other)
        {
            if (other == this)
            {
                throw new InvalidOperationException("Nó já conectado!");
            }
            if (_neighbours.Contains(other))
            {
                throw new InvalidOperationException("Nó já conectado!");
            }

            _neighbours.Add(other);
        }

        // Conexão em ambos os sentidos
        public void ConnectTwoWay(GraphNode<T> other)
        {
            ConnectOneWay(other);
            other.ConnectOneWay(this);
        }

        public void Disconnect(GraphNode<T> other)
        {
            if (other == this)
                throw new InvalidCastException("nó não conectado!");
            if (!_neighbours.Contains(other))
                throw new InvalidCastException("nó não conectado!");    
            _neighbours.Remove(other);

            
        }

        // Processamento em profundidade
        public void ProcessDepthFirst(GraphProcess<T> function)
        {
            List<GraphNode<T>> visited = new();
            ProcessDepthFirst(function, visited);
        }

        public void ProcessDepthFirst(GraphProcessConst<T> function)
        {
            void function2(ref T value)
            {
                function(value);
            }

            ProcessDepthFirst(function2);
        }

        private void ProcessDepthFirst(GraphProcess<T> function, List<GraphNode<T>> visited)
        {
            function(ref value);
            visited.Add(this);

            foreach(var neighbour in _neighbours)
            {
                if (!visited.Contains(neighbour))
                {
                    neighbour.ProcessDepthFirst(function, visited);
                }
            }
        }

        // Processamento em largura
        public void ProcessBreadthFirst(GraphProcess<T> function)
        {
            Queue<GraphNode<T>> toVisit = new();
            toVisit.Enqueue(this);

            List<GraphNode<T>> visited = new();

            while (toVisit.Count > 0)
            {
                GraphNode<T> node = toVisit.Dequeue();
                function(ref node.value);
                visited.Add(node);

                foreach (var neighbour in node._neighbours)
                {
                    if (!visited.Contains(neighbour) && !toVisit.Contains(neighbour))
                    {
                        toVisit.Enqueue(neighbour);
                    }
                }
            }
        }

        public void ProcessBreadthFirst(GraphProcessConst<T> function)
        {
            void function2(ref T value)
            {
                function(value);
            }

            ProcessBreadthFirst(function2);
        }
    }
}
