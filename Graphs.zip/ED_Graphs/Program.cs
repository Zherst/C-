﻿using Graphs;
using System.Text.RegularExpressions;


GraphAdjacencyList<String> list = new GraphAdjacencyList<String>();

var file = File.ReadAllLines("C:\\Users\\renat\\Downloads\\ED_Graphs_2\\ED_Graphs\\log.txt");
if (!file.Any()) { return; }
ProcessLog(file);

print();
void ProcessLog(string[] file)
{ 
    foreach (var line in file)
    {
        if (line.StartsWith("account"))
        {
            string name = line.Substring(("account".Length) + 1).Trim();
            if (!list.Vertices.Contains(name))
                list.AddVertex(name);
        }
        else if (line.StartsWith("follow"))
        {
            var numbers = Regex.Matches(line, @"\d+").Select(m => int.Parse(m.Value)).ToList();
            if (numbers.Count >= 2)
            {
                int from = numbers[0];
                int to = numbers[1];

                if (from < list.Vertices.Length && to < list.Vertices.Length)
                {
                    if (!list.HasEdge(from, to))
                        list.AddEdge(from, to);
                }
            }
            
        }
        else if (line.StartsWith("unfollow"))
        {
            var numbers = Regex.Matches(line, @"\d+").Select(m => int.Parse(m.Value)).ToList();
            if (numbers.Count >= 2)
            {
                int from = numbers[0];
                int to = numbers[1];

                if (from < list.Vertices.Length && to < list.Vertices.Length)
                {
                    if (list.HasEdge(from, to))
                        list.RemoveEdge(from, to);
                }
            }
        }
    }
}
    
void print()
{
    for (int i = 0; i < list.Vertices.Length; i++)
    {
        var name = list.GetVertex(i);
        var following = list.GetNeighbours(i);

        int followersCount = 0;
        int refollowing = 0;

        for (int j = 0; j < list.Vertices.Length; j++)
        {
            if (list.HasEdge(j,i))
            {
                followersCount++;
                if (list.HasEdge(i, j))
                    refollowing++;
            }
        }
        Console.Write($"[{i}] {name} - ");
        Console.Write($" Seguindo ({following.Count})");
        Console.Write($" Seguidores ({followersCount})");
        Console.WriteLine($" Seguindo de volta ({refollowing})");


    }
}