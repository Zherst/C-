﻿namespace Graphs
{
    // Representação de grafo(sem peso) usando lista de adjacência.
    internal class GraphAdjacencyList<T>
    {
        T[] _vertices = [];
        List<int>[] _edges = [];

        public T[] Vertices => _vertices;

        public void AddVertex(T value)
        {
            T[] newVertices = new T[_vertices.Length + 1];
            for (int i = 0; i < _vertices.Length; i++)
            {
                newVertices[i] = _vertices[i];
            }
            newVertices[_vertices.Length] = value;
            _vertices = newVertices;

            List<int>[] newEdges = new List<int>[_vertices.Length];
            for (int i = 0; i < _edges.Length; i++)
            {
                newEdges[i] = _edges[i];
            }
            newEdges[_edges.Length] = [];
            _edges = newEdges;
        }

        public T GetVertex(int index)
        {
            return _vertices[index];
        }

        public void AddEdge(int from, int to)
        {
            if (!_edges[from].Contains(to))
            {
                _edges[from].Add(to);
            }
        }

        public void RemoveEdge(int from, int to)
        {
            _edges[from].Remove(to);
        }

        public bool HasEdge(int from, int to)
        {
            return _edges[from].Contains(to);
        }

        public List<int> GetNeighbours(int index)
        {
            List<int> neighbours = new();

            for (int i = 0; i < _vertices.Length; i++)
            {
                if (HasEdge(index, i))
                {
                    neighbours.Add(i);
                }
            }
            return neighbours;
        }
    }
}
