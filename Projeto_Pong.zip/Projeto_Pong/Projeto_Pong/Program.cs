﻿

using OpenTK.Windowing.Common;
using OpenTK.Windowing.Desktop;
using Projeto_Pong;
using StbImageSharp;

StbImage.stbi_set_flip_vertically_on_load(1);

NativeWindowSettings settings = new()
{
    Title = "Pong 3D",
    ClientSize = new(1280, 720),
    APIVersion = new Version(4, 3),
    Profile = ContextProfile.Core,
    Flags = ContextFlags.ForwardCompatible
};
Game game = new(GameWindowSettings.Default, settings);
game.Run();