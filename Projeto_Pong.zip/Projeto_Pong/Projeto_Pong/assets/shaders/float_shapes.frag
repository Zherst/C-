#version 430 core

in vec3 f_Normal;
in vec3 f_Position;
in vec2 f_Uv;
in vec3 f_Color;
in vec4 f_ClipPos;

out vec4 out_Color;

uniform sampler2D u_SceneTexture;  
uniform vec3      u_CameraPosition;
uniform float     u_Time;

void main() {
    vec3 normal  = normalize(f_Normal);
    vec3 viewDir = normalize(u_CameraPosition - f_Position);

    float facing  = abs(dot(normal, viewDir));
    float fresnel = pow(1.0 - facing, 2.5);

    vec2 screenUv = (f_ClipPos.xy / f_ClipPos.w) * 0.5 + 0.5;

    float strength = 0.035 + fresnel * 0.025;
    vec2  distort  = normal.xy * strength;

    float r = texture(u_SceneTexture, screenUv + distort * 1.12).r;
    float g = texture(u_SceneTexture, screenUv + distort * 1.00).g;
    float b = texture(u_SceneTexture, screenUv + distort * 0.88).b;
    vec3  refracted = vec3(r, g, b);

    vec3 tint = f_Color * fresnel * 0.3;

    vec3  lightDir = normalize(vec3(0.2, 0.8, 0.5));
    float spec     = pow(max(dot(reflect(-lightDir, normal), viewDir), 0.0), 32.0);
    vec3  specular = vec3(1.0) * spec * 0.5;

    float pulse = 0.5 + 0.5 * sin(u_Time * 0.7 + f_Position.x * 0.4 + f_Position.z * 0.3);
    float alpha = mix(0.10, 0.50, fresnel) * (0.75 + 0.25 * pulse);

    out_Color = vec4(refracted + tint + specular, alpha);
}
