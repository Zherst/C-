#version 430 core

in vec3 f_Normal;
in vec3 f_Position;
in vec2 f_Uv;

out vec4 out_Color;

uniform sampler2D u_Texture;
uniform vec3  u_Color     = vec3(1.0, 0.8, 0.2);
uniform float u_Time      = 0.0;
uniform vec3  u_CameraPosition;

void main() {
    vec3  viewDir  = normalize(u_CameraPosition - f_Position);
    float fresnel  = 1.0 - abs(dot(normalize(f_Normal), viewDir));
    fresnel        = pow(fresnel, 2.5);

    float pulse    = 0.9 + 0.1 * sin(u_Time * 4.0 + f_Uv.x * 6.28);
    vec3  core     = u_Color * pulse;

    vec3  corona   = vec3(1.0, 0.3, 0.0) * fresnel * 2.5;

    float spots    = pow(max(sin(f_Uv.x * 12.0 + u_Time) * sin(f_Uv.y * 9.0 - u_Time * 0.7), 0.0), 6.0);
    vec3  flare    = vec3(1.0, 1.0, 0.5) * spots * 0.8;

    out_Color = vec4(core + corona + flare, 1.0);
}
