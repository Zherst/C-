#version 430 core

layout(location=0)in vec3 v_Position;
layout(location=1)in vec3 v_Normal;
layout(location=2)in vec2 v_Uv;

out vec3 f_Normal;
out vec3 f_Position;
out vec2 f_Uv;

uniform mat4 u_Model;
uniform mat4 u_View;
uniform mat4 u_Projection;
uniform float u_Time;

void main() {
    float pulse = 1.0 + 0.05 * sin(u_Time * 3.0);
    vec3 pos = v_Position * pulse;

    f_Position = (vec4(pos, 1.0) * u_Model).xyz;
    f_Normal   = v_Normal;
    f_Uv       = v_Uv;

    gl_Position = vec4(pos, 1.0) * u_Model * u_View * u_Projection;
}
