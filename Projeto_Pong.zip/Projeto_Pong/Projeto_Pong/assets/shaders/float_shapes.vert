#version 430 core

layout(location=0)in vec3 v_Position;
layout(location=1)in vec3 v_Normal;
layout(location=2)in vec2 v_Uv;
layout(location=3)in mat4 i_Model;   
layout(location=7)in vec3 i_Color;   

out vec3 f_Normal;
out vec3 f_Position;
out vec2 f_Uv;
out vec3 f_Color;
out vec4 f_ClipPos;

uniform mat4 u_View;
uniform mat4 u_Projection;

void main() {
    vec4 worldPos = vec4(v_Position, 1.0) * i_Model;

    f_Position = worldPos.xyz;
    f_Normal   = normalize((vec4(v_Normal, 0.0) * i_Model).xyz);
    f_Uv       = v_Uv;
    f_Color    = i_Color;

    gl_Position = worldPos * u_View * u_Projection;
    f_ClipPos   = gl_Position;
}
