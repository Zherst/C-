#version 430 core

in vec2 f_Uv;

out vec4 out_Color;

uniform sampler2D u_Texture;
uniform vec2  u_BubbleCenter = vec2(0.5, 0.5); // centro em UV [0,1]
uniform float u_BubbleT      = 0.0;             // 0..1
uniform float u_Aspect       = 1.777;

void main() {
    vec2 uv = f_Uv;

    vec2 centered  = uv - u_BubbleCenter;
    centered.x    *= u_Aspect;

    float dist     = length(centered);

    float waveR    = u_BubbleT * 0.8;
    float waveW    = 0.06 * (1.0 - u_BubbleT);   // anel que afina
    float envelope = exp(-pow((dist - waveR) / max(waveW, 0.001), 2.0));

    float strength = envelope * (1.0 - u_BubbleT) * 0.04;

    vec2 dir = dist > 0.0001 ? normalize(centered) : vec2(0.0);
    dir.x   /= u_Aspect;
    uv      += dir * strength;

    vec3 col = texture(u_Texture, clamp(uv, 0.0, 1.0)).rgb;

    float glow  = envelope * (1.0 - u_BubbleT);
    vec3  tint  = vec3(0.6 + 0.4 * sin(dist * 30.0),
                       0.6 + 0.4 * cos(dist * 25.0 + 1.0),
                       1.0) * glow * 1.5;

    out_Color = vec4(col + tint, 1.0);
}
