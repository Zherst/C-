#version 430 core

in vec2 f_Uv;

out vec4 out_Color;

uniform int   u_Score = 0;
uniform vec3  u_Color = vec3(1.0);

float segSDF(vec2 p, vec2 a, vec2 b) {
    vec2 pa = p - a;
    vec2 ba = b - a;
    float h = clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0);
    return length(pa - ba * h);
}

float digit(int d, vec2 p) {
    float px = p.x * 1.2 - 0.1; 
    float py = p.y;

    float sw  = 0.06;
    float r   = 9999.0;

    float x0 = 0.1, x1 = 0.9;
    float y0 = 0.05, y1 = 0.5, y2 = 0.95;

    // segmentos: a=topo, b=cima-dir, c=baixo-dir, d=base, e=baixo-esq, f=cima-esq, g=meio
    float sa = segSDF(vec2(px,py), vec2(x0,y2), vec2(x1,y2));
    float sb = segSDF(vec2(px,py), vec2(x1,y2), vec2(x1,y1));
    float sc = segSDF(vec2(px,py), vec2(x1,y1), vec2(x1,y0));
    float sd = segSDF(vec2(px,py), vec2(x0,y0), vec2(x1,y0));
    float se = segSDF(vec2(px,py), vec2(x0,y1), vec2(x0,y0));
    float sf = segSDF(vec2(px,py), vec2(x0,y2), vec2(x0,y1));
    float sg = segSDF(vec2(px,py), vec2(x0,y1), vec2(x1,y1));

    // Tabela de segmentos ativos por dígito (a,b,c,d,e,f,g)
    bool segs[7];
    if      (d==0) { segs = bool[7](true, true, true, true, true, true,false); }
    else if (d==1) { segs = bool[7](false,true, true,false,false,false,false); }
    else if (d==2) { segs = bool[7](true, true,false, true, true,false, true); }
    else if (d==3) { segs = bool[7](true, true, true, true,false,false, true); }
    else if (d==4) { segs = bool[7](false,true, true,false,false, true, true); }
    else if (d==5) { segs = bool[7](true,false, true, true,false, true, true); }
    else if (d==6) { segs = bool[7](true,false, true, true, true, true, true); }
    else if (d==7) { segs = bool[7](true, true, true,false,false,false,false); }
    else if (d==8) { segs = bool[7](true, true, true, true, true, true, true); }
    else           { segs = bool[7](true, true, true, true,false, true, true); } // 9

    float dists[7] = float[7](sa,sb,sc,sd,se,sf,sg);
    for (int i = 0; i < 7; i++) {
        if (segs[i]) r = min(r, dists[i]);
    }
    return r;
}

void main() {
    vec2 uv = f_Uv;

    int score = clamp(u_Score, 0, 99);
    int tens   = score / 10;
    int units  = score - tens * 10;

    float sdf;
    if (score < 10) {
        sdf = digit(units, vec2(uv.x, uv.y));
    } else {
        if (uv.x < 0.5) {
            sdf = digit(tens,  vec2(uv.x / 0.5, uv.y));
        } else {
            sdf = digit(units, vec2((uv.x - 0.5) / 0.5, uv.y));
        }
    }

    float thickness = 0.07;
    float aa        = fwidth(sdf);
    float alpha     = 1.0 - smoothstep(thickness - aa, thickness + aa, sdf);

    if (alpha < 0.01) discard;

    float glow = exp(-sdf * 12.0) * 0.5;
    out_Color  = vec4(u_Color + glow, alpha);
}
