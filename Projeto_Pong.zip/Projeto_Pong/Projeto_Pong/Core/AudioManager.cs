﻿using OpenTK.Audio.OpenAL;

namespace Projeto_Pong.Core
{
    internal class AudioManager : IDisposable
    {
        private ALDevice _device;
        private ALContext _context;

        private int _bufBounce;
        private int _bufPaddle;
        private int _bufScore;
        private int _bufExplosion;

        private int[] _sources;
        private int _sourceIndex = 0;
        private const int PoolSize = 8;

        public AudioManager()
        {
            _device = ALC.OpenDevice(null);
            _context = ALC.CreateContext(_device, (int[]?)null);
            ALC.MakeContextCurrent(_context);

            _sources = new int[PoolSize];
            AL.GenSources(PoolSize, _sources);

            _bufBounce = GenerateSine(800f, 0.06f, 0.08f);
            _bufPaddle = GenerateSine(440f, 0.10f, 0.12f);
            _bufScore = GenerateFanfare();
            _bufExplosion = GenerateNoise(0.15f);
        }

        private static int GenerateSine(float freq, float duration, float volume)
        {
            int sampleRate = 44100;
            int samples = (int)(sampleRate * duration);
            short[] data = new short[samples];

            for (int i = 0; i < samples; i++)
            {
                float t = (float)i / sampleRate;
                float env = MathF.Exp(-t / (duration * 0.4f));
                float wave = MathF.Sin(2f * MathF.PI * freq * t);
                data[i] = (short)(wave * env * volume * short.MaxValue);
            }
            return UploadBuffer(data, sampleRate);
        }

        private static int GenerateFanfare()
        {
            int sampleRate = 44100;
            float dur = 0.35f;
            int samples = (int)(sampleRate * dur);
            short[] data = new short[samples];

            float[] freqs = { 523.25f, 659.25f, 783.99f };
            for (int i = 0; i < samples; i++)
            {
                float t = (float)i/ sampleRate;
                int idx = (int)(t / (dur / freqs.Length));
                idx = Math.Clamp(idx, 0, freqs.Length - 1);
                float env = MathF.Exp(-5f * (t - idx * dur /  freqs.Length));
                float wave = MathF.Sin(2f * MathF.PI * freqs[idx] * t);
                data[i] = (short)(wave * env * 0.18f * short.MaxValue);
            }
            return UploadBuffer(data, sampleRate);
        }

        private static int GenerateNoise(float duration)
        {
            int sampleRate = 44100;
            int samples = (int)(sampleRate * duration);
            short[] data = new short[samples];
            var rng = new Random(42);

            for (int i = 0; i < samples; i++)
            {
                float t = (float)i / sampleRate;
                float env = MathF.Exp(-t / (duration * 0.3f));
                float low = MathF.Sin(2f * MathF.PI * 80f * t) * 0.5f;
                float noise = (float)(rng.NextDouble() * 2.0 - 1.0) * 0.5f;
                data[i] = (short)((low + noise) * env * 0.25f * short.MaxValue);
            }
            return UploadBuffer(data, sampleRate);
        }

        private static unsafe int UploadBuffer(short[] data, int sampleRate)
        {
            int buf = AL.GenBuffer();
            fixed (short* ptr = data)
            {
                AL.BufferData(buf, ALFormat.Mono16, (nint)ptr, data.Length * sizeof(short), sampleRate);
            }
            return buf;
        }

        private void Play(int buffer, float pitch = 1f, float gain = 1f)
        {
            int src = _sources[_sourceIndex % PoolSize];
            _sourceIndex++;

            AL.Source(src, ALSourcei.Buffer, buffer);
            AL.Source(src, ALSourcef.Pitch, pitch);
            AL.Source(src, ALSourcef.Gain, gain);
            AL.Source(src, ALSourceb.Looping, false);
            AL.SourcePlay(src);
        }

        public void PlayBounce() => Play(_bufBounce, 1.0f + (float)(new Random().NextDouble() * 0.1 - 0.05f));
        public void PlayPaddleHit() => Play(_bufPaddle, 1.0f);
        public void PlayScore() => Play(_bufScore, 1.0f, 1.2f);
        public void PlayExplosion() => Play(_bufExplosion, 1.0f, 1.5f);
    
        public void Dispose()
        {
            AL.DeleteSources(_sources);
            AL.DeleteBuffer(_bufBounce);
            AL.DeleteBuffer(_bufPaddle);
            AL.DeleteBuffer(_bufScore);
            AL.DeleteBuffer(_bufExplosion);
            ALC.DestroyContext(_context);
            ALC.CloseDevice(_device);
        }
    }
}
