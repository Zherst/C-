﻿using OpenTK.Graphics.OpenGL;
using System.IO;

namespace Projeto_Pong.Core
{
    internal abstract class Shader
    {
        private int _id = 0;
        public int Id => _id;
        protected abstract ShaderType Type { get; }

        protected Shader(string source)
        {
            _id = GL.CreateShader(Type);

            GL.ShaderSource(_id, source);
            GL.CompileShader(_id);
            GL.GetShader(_id, ShaderParameter.CompileStatus, out int status);
            string log = GL.GetShaderInfoLog(_id);
            if (status == 0)
            {
                Console.WriteLine($"FALHA COMPILAÇÃO Shader({Type}): {log}");
                Console.WriteLine($"--- source ---\n{source}");
            }
            else if (!string.IsNullOrEmpty(log))
            {
                Console.WriteLine($"Aviso Shader({Type}): {log}");
            }
        }

        public void Delete()
        {
            if (_id != 0)
            {
                GL.DeleteShader(_id);
            }
        }

        internal class VertexShader : Shader
        {
            protected override ShaderType Type => ShaderType.VertexShader;
            public VertexShader(string source) : base(source) { }

            public static VertexShader LoadFromFile(string filepath)
            {
                return new VertexShader(File.ReadAllText(filepath));
            }
        }

        internal class FragmentShader : Shader
        {
            protected override ShaderType Type => ShaderType.FragmentShader;
            public FragmentShader(string source) : base(source) { }
            public static FragmentShader LoadFromFile(string filepath)
            {
                return new FragmentShader(File.ReadAllText(filepath));
            }
        }
    }
}
