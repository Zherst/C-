﻿using OpenTK.Windowing.Common;
using OpenTK.Windowing.Desktop;
using OpenTK.Windowing.GraphicsLibraryFramework;
using OpenTK.Graphics.OpenGL;
using OpenTK.Mathematics;
using Projeto_Pong.Core;
using StbImageSharp;
using static Projeto_Pong.Core.Shader;


namespace Projeto_Pong
{
    internal class Game : GameWindow
    {
        private float _time = 0f;

        private const float FieldW = 20f;
        private const float FieldH = 12f;
        private const float PaddleW = 0.4f;
        private const float PaddleH = 2.5f;
        private const float PaddleD = 0.4f;
        private const float BallRadius = 0.35f;
        private const float PaddleSpeed = 10f;
        private const float BallInitspeed = 7f;

        //Mesh
        private Mesh _paddleMesh;
        private Mesh _ballMesh;
        private Mesh _fieldMesh;
        private Mesh _wallMesh;
        private Mesh _scoreMesh;
        private Mesh _postMesh;
        private Mesh _floatMesh;

        //Transforms
        private Transform _fieldTransform = new();
        private Transform _wallTopTransform = new();
        private Transform _wallBotTransform = new();

        //Material
        private Material _paddleMaterial;
        private Material _fieldMaterial;
        private Material _ballMaterial;
        private Material _wallMaterial;
        private Material _postMaterial;
        private Material _scoreMaterial;
        private Material _bubbleMaterial;
        private Material _floatMaterial;

        // Camera e luz
        private readonly Camera.PerspectiveCamera _camera;
        private readonly DirectionalLight _directionalLight = new();

        // RenderTargets
        private RenderTarget _shadowMap;
        private RenderTarget _postTarget;
        private RenderTarget _sceneSnapshot;

        //GameState
        private Vector2 _ballPos = Vector2.Zero;
        private Vector2 _ballVel;
        private float _paddle1Y = 0f;
        private float _paddle2Y = 0f;
        private int _score1 = 0;
        private int _score2 = 0;

        //Animacao Bola
        private bool _arcActive = false;
        private Vector2 _arcStart = Vector2.Zero;
        private Vector2 _arcEnd = Vector2.Zero;
        private float _arcT = 0f;
        private int _arcScorer = 0;

        //explosao
        private bool _bubbleActive = false;
        private float _bubbleT = 0f;
        private Vector2 _bubblePos = Vector2.Zero;

        //Forams Geometricas
        private const int Floatcount = 35;
        private Matrix4[] _floatModels = new Matrix4[Floatcount];
        private Vector3[] _floatBasePosition = new Vector3[Floatcount];
        private Vector3[] _floatBaseScales = new Vector3[Floatcount];
        private float[] _floatSpeeds = new float[Floatcount];

        // audio
        private AudioManager _audio;


        public Game(GameWindowSettings gameWindowSettings, NativeWindowSettings nativeWindowSettings) : base(gameWindowSettings, nativeWindowSettings)
        {
            StbImage.stbi_set_flip_vertically_on_load(1);

            _paddleMesh = Primitive.CreateRectangularPrism(PaddleW, PaddleH, PaddleD);
            _ballMesh = Primitive.CreateSphere(BallRadius, 32, 16);
            _fieldMesh = Primitive.CreateRectangularPrism(FieldW, 0.2f, 2f);
            _wallMesh = Primitive.CreateRectangularPrism(FieldW, 0.3f, 2f);
            _scoreMesh = Primitive.CreatePlaneXY(2f, 1f);
            _postMesh = Primitive.CreatePost();

            {
                _floatMesh = Primitive.CreateCube(1f);

                var colors = new Vector3[Floatcount];
                Random rng = new(42);

                for (int i = 0; i < Floatcount; i++)
                {
                    _floatBasePosition[i] = new Vector3((rng.NextSingle() - 0.5f) * FieldW * 1.8f, (rng.NextSingle() - 0.5f) * FieldH * 1.5f, -4f - rng.NextSingle() * 12f);
                    _floatBaseScales[i] = new Vector3(0.4f + rng.NextSingle() * 1.8f, 0.4f + rng.NextSingle() * 1.8f, 0.4f + rng.NextSingle() * 1.8f);
                    _floatSpeeds[i] = (rng.NextSingle() - 0.5f) * 60f;
                    colors[i] = new Vector3(0.3f + (rng.NextSingle() * 0.7f), 0.3f + (rng.NextSingle() * 0.7f), 0.5f + rng.NextSingle() * 0.5f);
                    _floatModels[i] = BuildFloatModel(i, 0f);
                }

                _floatMesh.SetInstanceData(3, _floatModels);
                _floatMesh.SetInstanceData(7, colors);
            }

            _fieldTransform.position = new Vector3(0f, -FieldH / 2f - 0.1f, 0f);
            _wallTopTransform.position = new Vector3(0f, FieldH / 2f + 0.15f, 0f);
            _wallBotTransform.position = new Vector3(0f, -FieldH / 2f - 0.15f, 0f);

            _shadowMap = RenderTarget.CreateDepth(2048, 2048);
            var size = nativeWindowSettings.ClientSize;
            _postTarget = RenderTarget.CreateColor(size.X, size.Y);
            _sceneSnapshot = RenderTarget.CreateColor(size.X, size.Y);

            _camera = new Camera.PerspectiveCamera(60f, (float)size.X / size.Y);
            _camera.position = new Vector3(0f, 5f, 18f);
            _camera.rotation = new Vector3(-15f, 0f, 0f);

            _directionalLight.color = new Vector3(1.5f, 1.3f, 0.8f);
            _directionalLight.rotation = new Vector3(-45f, 30f, 0f);

            //Shaders
            ShaderProgram phongProgram = new ShaderProgram(VertexShader.LoadFromFile("./assets/shaders/phong.vert"), FragmentShader.LoadFromFile("./assets/shaders/phong.frag"));
            ShaderProgram emissiveProgram = new ShaderProgram(VertexShader.LoadFromFile("./assets/shaders/emissive.vert"), FragmentShader.LoadFromFile("./assets/shaders/emissive.frag"));
            ShaderProgram postProgram = new ShaderProgram(VertexShader.LoadFromFile("./assets/shaders/post.vert"), FragmentShader.LoadFromFile("./assets/shaders/post.frag"));
            ShaderProgram bubbleProgram = new ShaderProgram(VertexShader.LoadFromFile("./assets/shaders/post.vert"), FragmentShader.LoadFromFile("./assets/shaders/bubble.frag"));
            ShaderProgram scoreProgram = new ShaderProgram(VertexShader.LoadFromFile("./assets/shaders/score.vert"), FragmentShader.LoadFromFile("./assets/shaders/score.frag"));
            ShaderProgram floatProgram = new ShaderProgram(VertexShader.LoadFromFile("./assets/shaders/float_shapes.vert"), FragmentShader.LoadFromFile("./assets/shaders/float_shapes.frag"));

            var white = TextureSettings.Texture.Default;

            _paddleMaterial = new(emissiveProgram);
            _paddleMaterial.SetVec3("u_Color", 0.1f, 0.1f, 0.8f);
            _paddleMaterial.SetFloat("u_Smoothness", 0.8f);
            _paddleMaterial.SetTexture("u_Texture", white);

            _fieldMaterial = new(phongProgram);
            _fieldMaterial.SetVec3("u_Color", 0.08f, 0.08f, 0.15f);
            _fieldMaterial.SetFloat("u_Smoothness", 0.3f);
            _fieldMaterial.SetTexture("u_Texture", white);


            _wallMaterial = new(phongProgram);
            _wallMaterial.SetVec3("u_Color", 0.3f, 0.3f, 0.5f);
            _wallMaterial.SetFloat("u_Smoothness", 0.2f);
            _wallMaterial.SetTexture("u_Texture", white);

            _ballMaterial = new(emissiveProgram);
            _ballMaterial.SetVec3("u_Color", 1.0f, 0.8f, 0.2f);
            _ballMaterial.SetTexture("u_Texture", white);

            _postMaterial = new(postProgram);
            _postMaterial.SetTexture("u_Texture", _postTarget.Texture);

            _scoreMaterial = new(scoreProgram);

            _bubbleMaterial = new(bubbleProgram);

            _floatMaterial = new(floatProgram);
            _floatMaterial.SetTexture("u_SceneTexture", _sceneSnapshot.Texture);
            _floatMaterial.cull = false;
            _floatMaterial.depthWrite = false;

            //Audio
            _audio = new AudioManager();

            Console.WriteLine($"GL Version: {GL.GetString(StringName.Version)}");

            ResetBall(1);
        }
        protected override void OnUpdateFrame(FrameEventArgs args)
        {
            base.OnUpdateFrame(args);

            float delta = (float)args.Time;
            _time += delta;

            if (KeyboardState.IsKeyDown(Keys.Escape))
                Close();

            if (!_arcActive)
            {
                if (KeyboardState.IsKeyDown(Keys.W) || KeyboardState.IsKeyDown(Keys.Up))
                    _paddle1Y += PaddleSpeed * delta;

                if (KeyboardState.IsKeyDown(Keys.S) || KeyboardState.IsKeyDown(Keys.Down))
                    _paddle1Y -= PaddleSpeed * delta;
                _paddle1Y = Math.Clamp(_paddle1Y, -(FieldH / 2 - PaddleH / 2), FieldH / 2 - PaddleH / 2);

                float aiDiff = _ballPos.Y - _paddle2Y;
                float aiStep = PaddleSpeed * 0.75f * delta;
                _paddle2Y += Math.Clamp(aiDiff, -aiStep, aiStep);
                _paddle2Y = Math.Clamp(_paddle2Y, -(FieldH / 2 - PaddleH / 2), FieldH / 2 - PaddleH / 2);

                UpdateBall(delta);
            }
            else
            {
                UpdateArc(delta);
            }

            if (_bubbleActive)
            {
                _bubbleT += delta / 0.7f;
                if (_bubbleT >= 1f) _bubbleActive = false;
            }

            _directionalLight.position = new Vector3(_ballPos.X, _ballPos.Y + 0.5f, 1.5f);

            for (int i = 0; i < Floatcount; i++)
                _floatModels[i] = BuildFloatModel(i, _time);
            _floatMesh.SetInstanceData(3, _floatModels);
        }

        private void Drawscene(Camera camera, bool drawFloats = true)
        {
            GL.ClearColor(0.02f, 0.02f, 0.05f, 1f);
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

            camera.GlobalApply();
            _shadowMap.Texture.Use(7);
            Material.SetGlobalInt("u_ShadowMap", 7);

            GL.CullFace(TriangleFace.Back);
            GL.DepthMask(true);

            _fieldMaterial.Use();
            _fieldTransform.Apply(_fieldMaterial);
            _fieldMesh.Draw();

            _wallMaterial.Use();
            _wallTopTransform.Apply(_wallMaterial);
            _wallMesh.Draw();

            _wallMaterial.Use();
            _wallBotTransform.Apply(_wallMaterial);
            _wallMesh.Draw();

            Transform tP1 = new();
            tP1.position = new Vector3(-(FieldW / 2f) + 0.8f, _paddle1Y, 0f);
            _paddleMaterial.Use();
            tP1.Apply(_paddleMaterial);
            _paddleMesh.Draw();

            Transform tP2 = new();
            tP2.position = new Vector3(FieldW / 2f - 0.8f, _paddle2Y, 0f);
            _paddleMaterial.Use();
            tP2.Apply(_paddleMaterial);
            _paddleMesh.Draw();

            Transform tBall = new();
            tBall.position = new Vector3(_ballPos.X, _ballPos.Y, 0f);
            _ballMaterial.Use();
            tBall.Apply(_ballMaterial);
            _ballMesh.Draw();

            _scoreMaterial.Use();
            camera.Apply(_scoreMaterial.Program);

            Transform ts1 = new();
            ts1.position = new Vector3(-FieldW * 0.5f + 1f, FieldH * 0.5f - 1f, 0f);
            ts1.scale = new Vector3(2f, 1.2f, 1f);
            ts1.Apply(_scoreMaterial);
            _scoreMaterial.Program.SetUniform("u_Score", _score1);
            _scoreMaterial.Program.SetUniform("u_Color", new Vector3(0.4f, 0.7f, 1.0f));
            _scoreMesh.Draw();

            Transform ts2 = new();
            ts2.position = new Vector3(FieldW * 0.5f - 1f, FieldH * 0.5f - 1f, 0f);
            ts2.scale = new Vector3(2f, 1.2f, 1f);
            ts2.Apply(_scoreMaterial);
            _scoreMaterial.Program.SetUniform("u_Score", _score2);
            _scoreMaterial.Program.SetUniform("u_Color", new Vector3(0.4f, 0.7f, 0.2f));
            _scoreMesh.Draw();

            if (_bubbleActive)
            {
                GL.Disable(EnableCap.DepthTest);
                _bubbleMaterial.Use();
                _postTarget.Texture.Use(0);
                _bubbleMaterial.Program.SetUniform("u_Texture", 0);

                Vector4 clip = new Vector4(_bubblePos.X, _bubblePos.Y, 0f, 1f) * camera.ViewMatrix * camera.ProjectionMatrix;
                Vector2 uv = (new Vector2(clip.X / clip.W, clip.Y / clip.W)) * 0.5f + new Vector2(0.5f);
                _bubbleMaterial.Program.SetUniform("u_BubbleCenter", uv);
                _bubbleMaterial.Program.SetUniform("u_BubbleT", _bubbleT);
                _bubbleMaterial.Program.SetUniform("u_Aspect", (float)Size.X / Size.Y);
                _postMesh.Draw();
                GL.Enable(EnableCap.DepthTest);
            }


            if (drawFloats)
            {
                _sceneSnapshot.Use();
                GL.Disable(EnableCap.DepthTest);
                GL.Clear(ClearBufferMask.ColorBufferBit);
                _postMaterial.Use();
                _postTarget.Texture.Use(0);
                _postMaterial.Program.SetUniform("u_Texture", 0);
                _postMesh.Draw();
                GL.Enable(EnableCap.DepthTest);

                _postTarget.Use();
                GL.Disable(EnableCap.DepthTest);
                GL.Enable(EnableCap.Blend);
                GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);

                _floatMaterial.Use();
                camera.Apply(_floatMaterial.Program);
                _floatMaterial.Program.SetUniform("u_Time", _time);
                _floatMaterial.Program.SetUniform("u_CameraPosition", camera.position);
                _floatMesh.Draw(Floatcount);

                GL.Enable(EnableCap.DepthTest);
                GL.BlendFunc(BlendingFactor.One, BlendingFactor.Zero);

            }
        }

        protected override void OnRenderFrame(FrameEventArgs args)
        {
            base.OnRenderFrame(args);

            float delta = (float)args.Time;

            GL.Enable(EnableCap.DepthTest);
            GL.Enable(EnableCap.CullFace);
            GL.CullFace(TriangleFace.Back);

            _directionalLight.GlobalApply();
            Camera shadowMapCamera = _directionalLight.GetLightMapCamera(new Vector3(_ballPos.X, _ballPos.Y, 0f));
            Material.SetGlobalMat4("u_Light", shadowMapCamera.ViewMatrix * shadowMapCamera.ProjectionMatrix);
            Material.SetGlobalFloat("u_Time", _time);
            Material.SetGlobalVec3("u_AmbientLight", new Vector3(0.8f, 0.8f, 0.8f));

            _shadowMap.Use();
            Drawscene(shadowMapCamera, false);

            _postTarget.Use();
            Drawscene(_camera);

            RenderTarget.Reset(this);
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
            
            GL.Disable(EnableCap.DepthTest);
            GL.Disable(EnableCap.CullFace);

            _postMaterial.Use();
            _postTarget.Texture.Use(0);
            _postMaterial.Program.SetUniform("u_Texture", 0);
            _postMesh.Draw();

            SwapBuffers();   
        }

        protected override void OnResize(ResizeEventArgs e)
        {
            base.OnResize(e);
            GL.Viewport(0,0,e.Width,e.Height);
            _camera.aspect = (float)e.Width / e.Height;

            _postTarget?.Destroy();
            _postTarget = RenderTarget.CreateColor(e.Width,e.Height);
            _postMaterial.SetTexture("u_Texture", _postTarget.Texture);

            _sceneSnapshot?.Destroy();
            _sceneSnapshot = RenderTarget.CreateColor(e.Width,e.Height);
            _floatMaterial.SetTexture("u_SceneTexture", _sceneSnapshot.Texture);
        }

        protected override void OnUnload()
        {
            base.OnUnload();
            _audio.Dispose();
            _shadowMap.Destroy();
            _postTarget.Destroy();
            _sceneSnapshot.Destroy();
        }

        private Matrix4 BuildFloatModel(int i, float time)
        {
            Transform ft = new();
            ft.position = new Vector3(_floatBasePosition[i].X + MathF.Sin(time * 0.25f + i * 0.9f) * 2.4f,
                                      _floatBasePosition[i].Y + MathF.Sin(time * 0.18f + i * 1.3f) * 1.5f,
                                      _floatBasePosition[i].Z + MathF.Cos(time * 0.20f + i * 0.6f) * 1.5f);
            ft.scale = _floatBaseScales[i];
            ft.rotation = new Vector3(_floatSpeeds[i] * 0.4f * time, _floatSpeeds[i] * time, _floatSpeeds[i] * 0.25f * time);

            return ft.ModelMatrix;
        }

        private void ResetBall(int serveDir)
        {
            _ballPos = Vector2.Zero;
            float angle = (float)(new Random().NextDouble() * 40 - 20) * MathF.PI / 180f;
            float dir = serveDir == 1 ? 1f : -1f;
            _ballVel = new Vector2(MathF.Cos(angle) * dir, MathF.Sin(angle)) * BallInitspeed;
        }

        private void UpdateBall(float dt)
        {
            _ballPos += _ballVel * dt;

            float halfh = FieldH / 2f - BallRadius;
            if (_ballPos.Y > halfh) 
            {
                _ballPos.Y = halfh;
                _ballVel.Y = -MathF.Abs(_ballVel.Y);
                _audio.PlayBounce();
            }
            if (_ballPos.Y < -halfh)
            {
                _ballPos.Y = -halfh;
                _ballVel.Y = MathF.Abs(_ballVel.Y);
                _audio.PlayBounce();
            }

            float px1 = -(FieldW / 2f) + 0.8f;
            float px2 = FieldW / 2f - 0.8f;

            if (_ballVel.X < 0 && _ballPos.X - BallRadius < px1 + PaddleW / 2f &&  _ballPos.X + BallRadius > px1 - PaddleW / 2f && Math.Abs(_ballPos.Y - _paddle1Y) < PaddleH / 2f + BallRadius)
            {
                float relY = (_ballPos.Y - _paddle1Y) / (PaddleH / 2f);
                float speed = _ballVel.Length * 1.04f;
                float angle = relY * 60f * MathF.PI / 180f;
                _ballVel = new Vector2(MathF.Cos(angle), MathF.Sin(angle)) * speed;
                _ballPos.X = px1 + PaddleW / 2f + BallRadius;
                _audio.PlayPaddleHit();
            }
            if (_ballVel.X > 0 && _ballPos.X + BallRadius > px2 - PaddleW / 2f && _ballPos.X - BallRadius < px2 + PaddleW / 2f && Math.Abs(_ballPos.Y - _paddle2Y) < PaddleH / 2f + BallRadius)
            {
                float relY = (_ballPos.Y - _paddle2Y) / (PaddleH / 2f);
                float speed = _ballVel.Length * 1.04f;
                float angle = relY * 60f * MathF.PI / 180f;
                _ballVel = new Vector2(-MathF.Cos(angle), MathF.Sin(angle)) * speed;
                _ballPos.X = px2 - PaddleW / 2f - BallRadius;
                _audio.PlayPaddleHit();
            }

            if (_ballPos.X < -FieldW / 2f - 1f) StartScore(2);
            else if (_ballPos.X > FieldW / 2f + 1f) StartScore(1);
        }

        private void StartScore(int scorer)
        {
            _bubbleActive = true;
            _bubbleT = 0f;
            _bubblePos = _ballPos;
            _audio.PlayExplosion();

            _arcActive = true;
            _arcT = 0f;
            _arcScorer = scorer;
            _arcStart = _ballPos;
            _arcEnd = scorer == 1 ? new Vector2(-FieldW * 0.5f + 1f, FieldH * 0.5f - 1f) : new Vector2(FieldW * 0.5f - 1f, FieldH * 0.5f - 1f);

        }

        private void UpdateArc(float dt)
        {
            _arcT += dt / 0.9f;
            if (_arcT >= 1f)
            {
                _arcT = 1f;
                _arcActive = false;
                if (_arcScorer == 1) _score1++;
                else _score2++;
                _audio.PlayScore();

                int loser = _arcScorer == 1 ? 1 : 2;
                ResetBall(loser);
                return;
            }
            float t = _arcT;
            Vector2 ctrl = new((_arcStart.X + _arcEnd.X) / 2f, FieldH * 0.5f + 3f);
            _ballPos = (1 - t) * (1 - t) * _arcStart + 2 * (1 - t) * t * ctrl + t * t * _arcEnd;
        }

        
    }
}
