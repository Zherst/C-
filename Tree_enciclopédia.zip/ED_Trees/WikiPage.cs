﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ED_Trees
{
    internal class WikiPage
    {
        public string Name { get; set; }
        public int VisitCount { get; set; }

        public WikiPage(string name)
        {
            Name = name;
            VisitCount = 0;
        }
    }
}
