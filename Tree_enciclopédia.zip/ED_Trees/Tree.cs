class Tree<T>
{
    public T value;
    private Tree<T>? _parent;
    public Tree<T>? Parent => _parent;
    private List<Tree<T>> _children = new();
    public int ChildrenCount => _children.Count;

    public delegate void Process(ref T value);

    private Tree(T value, Tree<T>? parent = null)
    {
        this.value = value;
        _parent = parent;
    }

    public Tree(T value) : this(value, null) { }

    public Tree<T> AddChild(T value)
    {
        _children.Add(new Tree<T>(value, this));
        return _children[_children.Count - 1];
    }

    public Tree<T> GetChild(int index)
    {
        return _children[index];
    }

    public void ProcessDepthFirst(Process function)
    {
        function(ref value);
        foreach (var child in _children)
        {
            child.ProcessDepthFirst(function);
        }
    }

    public void ProcessBreadthFirst(Process function)
    {
        Queue<Tree<T>> queue = new([this]);

        while (queue.Count > 0)
        {
            Tree<T> t = queue.Dequeue();
            function(ref t.value);
            foreach (var child in t._children)
            {
                queue.Enqueue(child);
            }
        }
    }
}