﻿using ED_Trees;
using System.Reflection.Emit;
using System.Reflection.Metadata.Ecma335;
using System.Xml.Linq;

class Program
{
    static void Main()
    {
        var lines = File.ReadAllLines("C:\\Users\\renat\\Downloads\\ED_Trees (1)\\ED_Trees\\wiki.txt");
        if (!lines.Any()) return;
        string logfile = "C:\\Users\\renat\\Downloads\\ED_Trees (1)\\ED_Trees\\log.txt";

        String FirstLine = lines[0].TrimStart('.');
        var root = new Tree<WikiPage>(new WikiPage(FirstLine));
        int index = 1;

        BuildTree(lines, ref index, root, 0);

        ProcessLog(root, logfile);

        PrintTree(root, 0);

        static void BuildTree(string[] lines, ref int index, Tree<WikiPage> parent, int parentDepth)
        {
            while (index < lines.Length)
            {
                int depth = 0;
                string line = lines[index];

                while (depth < lines.Length && lines[index][depth] == '.') depth++;
                if (depth <= parentDepth) return;

                string name = line.Substring(depth).Trim();
                var child = parent.AddChild(new WikiPage(name));

                index++;

                BuildTree(lines, ref index, child, depth);
            }
        }

        static void PrintTree(Tree<WikiPage> node, int depth)
        {
            Console.WriteLine($"{new string(' ', depth * 2)}- {node.value.Name} (Acessos: {node.value.VisitCount})");
            for (int i = 0; i < node.ChildrenCount; i++)
            {
                PrintTree(node.GetChild(i), depth + 1);
            }
        }

        static void ProcessLog(Tree<WikiPage> home, string logpath)
        {
            foreach (var line in File.ReadAllLines(logpath))
            {
                var current = home;

                current.value.VisitCount++;
                foreach (char action in line)
                {
                    if (char.IsDigit(action))
                    {
                        int index = action - '0';
                        if (index < current.ChildrenCount)
                        {
                            current = current.GetChild(index);
                            current.value.VisitCount++;
                        }
                    }
                    else if (action == 'b' || action == 'B')
                    {
                        if (current.Parent != null)
                            current = current.Parent;
                    }
                }
            }
        }
    }
}
    