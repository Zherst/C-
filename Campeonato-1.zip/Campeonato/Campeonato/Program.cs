﻿string[] fileBlocks = File.ReadAllLines("./blockbreaker.txt");
string[] fileSpeed = File.ReadAllLines("./speedracer.txt");

int[] blocos = new int[10];
int[] speed = new int[10];
int l;

for (int i = 1; i <= fileBlocks.Length-1; i ++)
{
    if (i % 2 == 0) { 
        l = Int32.Parse(fileBlocks[i]);
        blocos[l] += Int32.Parse(fileBlocks[i + 1]);
    }
}

for (int i = 1; i <= fileSpeed.Length - 1; i++)
{
    int t;
    if (i % 2 == 0)
    {
        l = Int32.Parse(fileSpeed[i]);
        t = Int32.Parse(fileSpeed[i + 1]);
        if (speed[l] > t || speed[l] == 0)
        {
            speed[l] = t;
        }
    }
}


Console.WriteLine("\nQuantidade de Pontos: \n");
for (int i = 0; i < blocos.Length; i++)
{
    Console.WriteLine($"Equipe {i} - {blocos[i]} Pontos");
}

Console.WriteLine("\n Tempo: \n");
for (int i = 0; i < speed.Length; i++)
{
    Console.WriteLine($"Equipe {i} - {speed[i]}s");
}




var rankbloco = blocos.Select((valor, time) => (valor, time)).ToList();
rankbloco.Sort((a,b) => b.valor.CompareTo(a.valor));

var rankspeed = speed.Select((tempo,time) => (tempo, time)).ToList();
rankspeed.Sort((a,b) => a.tempo.CompareTo(b.tempo));

Console.WriteLine("Quantidade de Pontos \n");
foreach (var item in rankbloco)
{
    Console.WriteLine($"Time: { item.time} - Pontos: {item.valor}");
}

Console.WriteLine("\nMenor Tempo: \n");
foreach (var item in rankspeed)
{
    Console.WriteLine($"Time: {item.time} - Tempo: {item.tempo}s");
}



Console.WriteLine($"\nVencedor do blockbreaker: Equipe {rankbloco[0].time}\n");
Console.WriteLine($"\nVencedor do speedracer: Equipe {rankspeed[0].time}\n");