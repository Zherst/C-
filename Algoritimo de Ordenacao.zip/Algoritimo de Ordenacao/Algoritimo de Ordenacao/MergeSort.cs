﻿using Algoritimo_de_Ordenacao;

static class MergeSort
{
    public static void Sort(List<Weapon> list, int left, int right, WeaponComparer comparer)
    {
        if (left < right)
        {
            int middle = (left + right) / 2;
            Sort(list, left, middle, comparer);
            Sort(list, middle + 1, right, comparer);
            Merge(list, left, middle, right, comparer);
        }
    }

    private static void Merge(List<Weapon> list, int left, int middle, int right, WeaponComparer comparer)
    {
        int leftSize = middle - left + 1;
        int rightSize = right - middle;

        var leftArray = new Weapon[leftSize];
        var rightArray = new Weapon[rightSize];

        for (int i = 0; i < leftSize; i++)
            leftArray[i] = list[left + i];
        for (int j = 0; j < rightSize; j++)
            rightArray[j] = list[middle + 1 + j];

        int iLeft = 0, iRight = 0, k = left;

        while (iLeft < leftSize && iRight < rightSize)
        {
            if (comparer.Compare(leftArray[iLeft], rightArray[iRight]) < 0)
            {
                list[k] = leftArray[iLeft];
                iLeft++;
            }
            else
            {
                list[k] = rightArray[iRight];
                iRight++;
            }
            k++;
        }

        while (iLeft < leftSize)
        {
            list[k++] = leftArray[iLeft++];
        }
        while (iRight < rightSize)
        {
            list[k++] = rightArray[iRight++];
        }
    }
}