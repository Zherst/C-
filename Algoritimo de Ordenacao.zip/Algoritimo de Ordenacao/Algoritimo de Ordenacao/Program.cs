﻿using Algoritimo_de_Ordenacao;

class Weapon
{
    public string name { get; set; }
    public string rarity { get; set; }
    public int damage { get; set; }

    public override string ToString()
    {
        return $"{name} | {rarity} | {damage}";
    }
}
class Program
{
    static void Main()
    {
        var rarityRank = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase)
            {
                { "common", 1 },
                { "rare", 2 },
                { "epic", 3 },
                { "legendary", 4 }
            };

        var weapons = LoadWeapons("weapons.txt");
        var comparer = new WeaponComparer(rarityRank);

        Console.WriteLine("Escolha o algoritmo:");
        Console.WriteLine("1 - QuickSort");
        Console.WriteLine("2 - MergeSort");
        Console.WriteLine("3 - RandomSort");

        string choice = Console.ReadLine();

        switch (choice)
        {
            case "1":
                QuickMerge.Sort(weapons, 0, weapons.Count - 1, comparer);
                break;
            case "2":
                MergeSort.Sort(weapons, 0, weapons.Count - 1, comparer);
                break;
            case "3":
                weapons = RandomSort.Sort(weapons);
                break;
            default:
                Console.WriteLine("Opção inválida!");
                return;
        }

        Console.WriteLine("\nResultado da ordenação:\n");
        foreach (var w in weapons)
            Console.WriteLine(w);
    }

    static List<Weapon> LoadWeapons(string file)
    {
        var weapons = new List<Weapon>();
        var lines = File.ReadAllLines(file);

        for (int i = 0; i < lines.Length; i += 3)
        {
            if (i + 2 >= lines.Length) break;

            weapons.Add(new Weapon
            {
                name = lines[i].Trim(),
                rarity = lines[i + 1].Trim(),
                damage = int.TryParse(lines[i + 2].Trim(), out int dmg) ? dmg : 0
            });
        }
        return weapons;
    }
}