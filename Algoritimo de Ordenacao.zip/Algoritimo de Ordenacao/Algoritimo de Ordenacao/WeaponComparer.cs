﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algoritimo_de_Ordenacao
{
    internal class WeaponComparer
    {
        private readonly Dictionary<String, int> rerityRank;

        public WeaponComparer(Dictionary<String, int> rerityRank)
        {
            this.rerityRank = rerityRank;
        }

        public int Compare(Weapon a, Weapon b)
        {
            int rankA = rerityRank.ContainsKey(a.rarity) ? rerityRank[a.rarity] : 0;
            int rankB = rerityRank.ContainsKey(b.rarity) ? rerityRank[b.rarity] : 0;

            if (rankA != rankB) return rankA.CompareTo(rankB);

            if (a.damage != b.damage) return a.damage.CompareTo(b.damage);

            return String.Compare(a.name, b.name, StringComparison.OrdinalIgnoreCase);
        }
    }
}
