﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algoritimo_de_Ordenacao
{
    internal class RandomSort
    {
        public static List<Weapon> Sort(List<Weapon> list)
        {
            if (list.Count <= 1) return list;

            int mid = list.Count / 2;
            var left = Sort(list.GetRange(0, mid));
            var right = Sort(list.GetRange(mid,list.Count - mid));

            return SortHelper.MergeRandom(left,right);
        }
    }
}
