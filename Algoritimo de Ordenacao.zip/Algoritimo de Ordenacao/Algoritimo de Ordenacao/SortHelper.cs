﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algoritimo_de_Ordenacao
{
    internal class SortHelper
    {
        private static Random rng = new Random();

        public static void Swap(List<Weapon> list, int i, int j)
        {
            Weapon temp = list[i];
            list[i] = list[j];
            list[j] = temp;
        }

        public static int Partition(List<Weapon> list, int left, int right, WeaponComparer comparer)
        {
            Weapon pivot = list[right];
            int i = left - 1;

            for (int j = left; j < right; j++)
            {
                if (comparer.Compare(list[j], pivot) < 0)
                {
                    i++;
                    Swap(list, i, j);
                }
            }
            Swap(list, i + 1, right);
            return i + 1;
        }

        public static List<Weapon> MergeRandom(List<Weapon> left, List<Weapon> right) 
        {
            var result = new List<Weapon>();

            while (left.Count > 0 && right.Count > 0)
            {
                bool pickLeft = rng.Next(2) == 0;
                if (pickLeft)
                {
                    result.Add(left[0]);
                    left.RemoveAt(0);
                }
                else
                {
                    result.Add(right[0]);
                    right.RemoveAt(0);
                }
            }

            result.AddRange(left);
            result.AddRange(right);

            return result;
        }
    }
}
