﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algoritimo_de_Ordenacao
{
    static class QuickMerge
    {
        public static void Sort(List<Weapon> list, int left, int right, WeaponComparer comparer)
        {
            if (left >= right) return;

            int pivotIndex = SortHelper.Partition(list, left, right, comparer);
            Sort(list, left, pivotIndex - 1, comparer);
            Sort(list, pivotIndex + 1, right, comparer);
        }
    }
}
